/**
 * SaveSystem - CodeQuest
 * Pure utility for localStorage persistence.
 */

export const SaveSystem = {
    KEY: 'cq_save_data',

    hasSave() {
        return localStorage.getItem(this.KEY) !== null;
    },

    save(data) {
        localStorage.setItem(this.KEY, JSON.stringify({
            ...data,
            timestamp: Date.now()
        }));
        console.log('Game Saved Locally');
    },

    load() {
        try {
            const raw = localStorage.getItem(this.KEY);
            if (!raw) return null;
            return JSON.parse(raw);
        } catch (e) {
            console.error('Failed to load save data:', e);
            return null;
        }
    },

    clear() {
        localStorage.removeItem(this.KEY);
    }
};
